/**************************************************************************
 ��  �� ���������
 �Ա���ַ��https://shop119207236.taobao.com
**************************************************************************/

#include "SHOW.h"

void overview(void)
{
		OLED_ShowString(0,0,"ANGLE:",12);
		if(pitch<0)		
		{
			OLED_ShowString(48,0,"-",12); 
			OLED_Float(0,56,-pitch,3);
		}	
		else	
		{
			OLED_ShowString(48,0,"+",12); 
			OLED_Float(0,56,pitch,3);			
		}
		OLED_ShowString(0,1,"BAT :",12);
		OLED_Float(1,48,Voltage,2);						//��ʾ��ѹ
		OLED_ShowString(90,1,"V",12);
		
		OLED_ShowString(0,2,"L :",12);
		OLED_Num3(5,2,Encoder_Left);					//��ʾ��ߵ���ı�����ֵ
		OLED_ShowString(60,2,"R :",12);	
		OLED_Num3(16,2,Encoder_Right);					//��ʾ�ұߵ���ı�����ֵ
		
		OLED_ShowString(0,3,"SPD:",12);
		OLED_Num3(5,3,Target_Speed);					//��ʾĿ��ֱ���ٶ�
		OLED_ShowString(60,3,"TURN:",12);
		OLED_Num3(16,3,Turn_Speed);					//��ʾĿ��ת���ٶ�
			
		OLED_ShowString(0,7,"MODE:",12);
		switch(CTRL_MODE)
		{
			case 2:
				OLED_ShowString(48,7,"SR04",12);
				OLED_ShowString(0,4,"Distance:",12);
				OLED_Float(5,10,SR04_Distance,2);
			break;
			case 1:
				OLED_ShowString(48,7,"Bluetooth",12);
			break;
			case 3:
				OLED_ShowString(48,7,"Tracking",12);
				OLED_Num_write(4,5,C4);					//��ʾ�����ֵ
				OLED_Num_write(8,5,C3);
				OLED_Num_write(12,5,C2);
				OLED_Num_write(16,5,C1);
			break;
			case 4:
				OLED_ShowString(48,7,"PS2",12);
				OLED_ShowString(0,4,"LX:",12);	
				OLED_ShowString(60,4,"LY:",12);
				OLED_ShowString(0,5,"RX:",12);	
				OLED_ShowString(60,5,"RY:",12);
				OLED_Num3(4,4,PS2_LX);					//��ʾPS2ҡ������
				OLED_Num3(14,4,PS2_LY);
				OLED_Num3(4,5,PS2_RX);
				OLED_Num3(14,5,PS2_RY);
			break;
		}
}
void debug(void)
{
		OLED_ShowString(0,0,"Balance:",12);
		OLED_ShowString(0,1,"KP:",12);
		OLED_ShowString(0,2,"KD:",12);
		OLED_ShowString(0,3,"Velocity:",12);
		OLED_ShowString(0,4,"KP:",12);
		OLED_ShowString(0,5,"KI:",12);
	
		if(balance_KP<0)		
		{
			OLED_ShowString(48,1,"-",12); 
			OLED_Float(1,64,-balance_KP,5);
		}	
		else	
		{
			OLED_ShowString(48,1,"+",12); 
			OLED_Float(1,64,balance_KP,5);
		}
		
		if(balance_KD<0)		
		{
			OLED_ShowString(48,2,"-",12); 
			OLED_Float(2,64,-balance_KD,5);
		}	
		else	
		{
			OLED_ShowString(48,2,"+",12); 
			OLED_Float(2,64,balance_KD,5);
		}
		
		if(velocity_KP<0)		
		{
			OLED_ShowString(48,4,"-",12); 
			OLED_Float(4,64,-velocity_KP,5);
		}	
		else	
		{
			OLED_ShowString(48,4,"+",12); 
			OLED_Float(4,64,velocity_KP,5);
		}
		
		if(velocity_KI<0)		
		{
			OLED_ShowString(48,5,"-",12); 
			OLED_Float(5,64,-velocity_KI,5);
		}	
		else	
		{
			OLED_ShowString(48,5,"+",12); 
			OLED_Float(5,64,velocity_KI,5);
		}
}
void sensor()
{
		OLED_ShowString(0,0,"Pitch:",12);
		OLED_ShowString(0,1,"Roll :",12);
		OLED_ShowString(0,2,"Yaw  :",12);
		if(pitch<0)
		{
			OLED_ShowString(56,0,"-",12); 
			OLED_Float(0,64,-pitch,2);
		}	
		else
		{
			OLED_ShowString(56,0,"+",12); 
			OLED_Float(0,64,pitch,2);
		}
		if(pitch<10 && pitch>-10)OLED_ShowString(96,0," ",12); 
		if(pitch<100 && pitch>-100)OLED_ShowString(104,0," ",12); 
		if(roll<0)
		{
			OLED_ShowString(56,1,"-",12); 
			OLED_Float(1,64,-roll,2);
		}	
		else
		{
			OLED_ShowString(56,1,"+",12); 
			OLED_Float(1,64,roll,2);
		}
		if(roll<10 && roll>-10)OLED_ShowString(96,1," ",12); 
		if(roll<100 && roll>-100)OLED_ShowString(104,1," ",12); 
		
		if(yaw<0)
		{
			OLED_ShowString(56,2,"-",12); 
			OLED_Float(2,64,-yaw,2);
		}	
		else	
		{
			OLED_ShowString(56,2,"+",12); 
			OLED_Float(2,64,yaw,2);
		}
		if(yaw<10 && yaw>-10)OLED_ShowString(96,2," ",12); 
		if(yaw<100 && yaw>-100)OLED_ShowString(104,2," ",12); 
}
void oled_show(void)
{
		static u8 index=0,ctrl_mode=0;
		if(index!=oled_index ||ctrl_mode!=CTRL_MODE)
		{
			OLED_Clear();
			index=oled_index;
			ctrl_mode=CTRL_MODE;
		}
		switch(index)
		{
			case 0:
				overview();
				break;
			case 1:
				debug();
				break;
			case 2:
				sensor();
				break;
		}
}


