#include "sys.h"

void VOFA(void);
void CH_FloatSend(unsigned char * send);
void DataReceived(unsigned char Res);
